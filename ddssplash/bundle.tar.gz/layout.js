{
    "id" : "slide",
        "type" : "ClutterGroup",
        "visible" : true,
        "children" : [
            {
                "id" : "splash",
                    "type" : "ClutterTexture",
                    "filename" : "dds-logo.png",
                    "x" : 0,
                    "y" : 0,
                    "width" : 1920,
                    "height": 1080,
                    "visible" : true
                    }

    ]
        }
