{"transition": "fade", "mode": "module"}
