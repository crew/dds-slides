{
    "id" : "slide",
        "type" : "ClutterGroup",
        "visible" : true,
        "children" : [
            {
                "id" : "townhall",
                    "type" : "ClutterTexture",
                    "filename" : "gettingstuffdon.jpg",
                    "x" : 0,
                    "y" : 0,
                    "width" : 1920,
                    "height": 1080,
                    "visible" : true
                    }

    ]
        }
